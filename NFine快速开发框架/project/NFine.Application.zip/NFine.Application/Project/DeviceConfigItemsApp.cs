﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NFine.Code;
using NFine.Domain.Entity.Project;
using NFine.Domain.IRepository.Project;
using NFine.Domain.IRepository.SystemManage;
using NFine.Repository.Project;
using NFine.Repository.SystemManage;

namespace NFine.Application.Project
{
    public class DeviceConfigItemsApp
    {
        private IDeviceConfigItemsRepository service = new DeviceConfigItemsRepository();

        /// <summary>
        /// 获取列表信息
        /// </summary>
        /// <returns></returns>
        public List<DeviceConfigItemsEntity> GetList()
        {
            return service.IQueryable().ToList();
        }
        public List<DeviceConfigItemsEntity> GetList(string keyValue)
        {
            return service.IQueryable(m => m.F_DeviceId == keyValue).ToList();
        }
        /// <summary>
        /// 根据ID获取信息
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        public DeviceConfigItemsEntity GetForm(string keyValue)
        {
            return service.FindEntity(keyValue);
        }

        /// <summary>
        /// 删除 from信息
        /// </summary>
        /// <param name="keyValue"></param>
        public void DeleteForm(string keyValue)
        {
            service.Delete(t => t.F_DeviceId == keyValue);
        }

        /// <summary>
        /// 提交表单信息
        /// </summary>
        /// <param name="deviceConfigEntity"></param>
        /// <param name="keyValue"></param>
        public void SubmitForm(DeviceConfigItemsEntity deviceConfigEntity, string keyValue)
        {
            if (!string.IsNullOrEmpty(keyValue))
            {
                service.Update(deviceConfigEntity);
            }
            else
            {
                service.Insert(deviceConfigEntity);
            }
        }
    }
}
