﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NFine.Domain.Entity.Project;
using NFine.Domain.IRepository.Project;
using NFine.Domain.IRepository.SystemManage;
using NFine.Repository.Project;
using NFine.Repository.SystemManage;

namespace NFine.Application.Project
{
    public class ProjectTemplateItemsApp
    {
        private IProjectTemplateItemsRepository service = new ProjectTemplateItemsRepository();

        /// <summary>
        /// 获取列表信息
        /// </summary>
        /// <returns></returns>
        public List<ProjectTemplateItemsEntity> GetList()
        {
            return service.IQueryable().ToList();
        }

        public List<ProjectTemplateItemsEntity> GetList(string keyValue)
        {
            return service.IQueryable(m => m.F_TemplateId == keyValue).OrderByDescending(m => m.F_ParentName).ToList();
        }
        /// <summary>
        /// 根据ID获取信息
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        public ProjectTemplateItemsEntity GetForm(string keyValue)
        {
            return service.FindEntity(keyValue);
        }

        /// <summary>
        /// 删除 from信息
        /// </summary>
        /// <param name="keyValue"></param>
        public void DeleteForm(string keyValue)
        {
            string[] strArr = keyValue.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            if (strArr.Length > 0)
            {
                foreach (var itm in strArr)
                {
                    service.Delete(t => t.F_Id == itm);
                }
            }
        }

        /// <summary>
        /// 提交表单信息
        /// </summary>
        /// <param name="deviceConfigEntity"></param>
        /// <param name="keyValue"></param>
        public void SubmitForm(ProjectTemplateItemsEntity entity, string keyValue)
        {
            if (!string.IsNullOrEmpty(keyValue))
            {
                service.Update(entity);
            }
            else
            {
                entity.F_Id = NFine.Code.Common.GuId();
                
                if (!string.IsNullOrEmpty(entity.F_AccessoryUrl))
                {
                    entity.F_AccessoryUrl = entity.F_AccessoryUrl.Replace("&nbsp;", "");
                }
                entity.F_Type = "物料";
                service.Insert(entity);
            }
        }
    }
}
