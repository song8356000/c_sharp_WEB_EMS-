﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NFine.Code;
using NFine.Domain.Entity.Project;
using NFine.Domain.IRepository.Project;
using NFine.Domain.IRepository.SystemManage;
using NFine.Repository.Project;
using NFine.Repository.SystemManage;

namespace NFine.Application.Project
{
    public class DeviceConfigApp
    {
        private IDeviceConfigRepository service = new DeviceConfigRepository();

        /// <summary>
        /// 获取列表信息
        /// </summary>
        /// <returns></returns>
        public List<DeviceConfigEntity> GetList()
        {
            return service.IQueryable().OrderBy(t => t.F_CreatorTime).ToList();
        }
        public List<DeviceConfigEntity> GetList(Pagination pagination, string keyword)
        {
            var expression = ExtLinq.True<DeviceConfigEntity>();
            if (!string.IsNullOrEmpty(keyword))
            {
                expression = expression.And(t => t.F_Id.Contains(keyword));
            }
            return service.FindList(expression, pagination);
        }

        /// <summary>
        /// 根据ID获取信息
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        public DeviceConfigEntity GetForm(string keyValue)
        {
            return service.FindEntity(keyValue);
        }

        /// <summary>
        /// 删除 from信息
        /// </summary>
        /// <param name="keyValue"></param>
        public void DeleteForm(string keyValue)
        {
            service.Delete(t => t.F_Id == keyValue);
        }

        /// <summary>
        /// 提交表单信息
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="keyValue"></param>
        public void SubmitForm(DeviceConfigEntity entity, string keyValue)
        {
            if (!string.IsNullOrEmpty(keyValue))
            {
                service.Update(entity);
            }
            else
            {
                //entity.Create();
                entity.F_CreatorTime=DateTime.Now;
                entity.F_LastModifyUserId = NFine.Code.OperatorProvider.Provider.GetCurrent().UserCode;
                entity.F_CreatorUserId = NFine.Code.OperatorProvider.Provider.GetCurrent().UserCode;
                entity.F_LastModifyTime=DateTime.Now;;
                service.Insert(entity);
            }
        }
    }
}
