﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NFine.Code.Flow
{
    public static class FlowHanle
    {
        /// <summary>
        /// 获取下一个状态
        /// </summary>
        /// <param name="current"></param>
        /// <returns></returns>
        public static int GetNextStatue(int current)
        {
            switch (current)
            {
                case (int)ProjectFlowStatue.Draft:
                    return (int)ProjectFlowStatue.Distribution;
                case (int)ProjectFlowStatue.Sales:
                    return (int)ProjectFlowStatue.Distribution;
                case (int)ProjectFlowStatue.Distribution:
                    return (int)ProjectFlowStatue.NPIAudit;
                case (int)ProjectFlowStatue.NPIAudit:
                    return (int)ProjectFlowStatue.NPIAdminAudit;
                case (int)ProjectFlowStatue.NPIAdminAudit:
                    return (int)ProjectFlowStatue.Release;
            }
            return 0;
        }
        /// <summary>
        /// 获取上一个状态
        /// </summary>
        /// <param name="current"></param>
        /// <returns></returns>
        public static int GetOnStatue(int current)
        {
            switch (current)
            {
                case (int)ProjectFlowStatue.Draft:
                    return (int)ProjectFlowStatue.Draft;
                case (int)ProjectFlowStatue.Distribution:
                    return (int)ProjectFlowStatue.Sales;
                case (int)ProjectFlowStatue.NPIAudit:
                    return (int)ProjectFlowStatue.Distribution;
                case (int)ProjectFlowStatue.NPIAdminAudit:
                    return (int)ProjectFlowStatue.NPIAudit;
            }
            return 0;
        }
        /// <summary>
        /// 获取角色
        /// </summary>
        /// <param name="currentStatue"></param>
        /// <returns></returns>
        public static string GetRole(int currentStatue)
        {
            switch (currentStatue)
            {
                case (int)ProjectFlowStatue.Draft:
                    return "NPIAdmin";
                case (int)ProjectFlowStatue.Distribution:
                    return "NPIAdmin";
                case (int)ProjectFlowStatue.NPIAudit:
                    return "NPI";
                case (int)ProjectFlowStatue.NPIAdminAudit:
                    return "NPIAdmin";

            }
            return string.Empty;
        }

        /// <summary>
        /// 获取备注模板
        /// </summary>
        /// <param name="action"></param>
        /// <param name="remak"></param>
        /// <returns></returns>
        public static string GetRemarkTemplate(int action, string remak)
        {
            string tex = "";
            if (action == (int)ActionType.Consent)
            {
                tex = "同意";
            }
            else
            {
                tex = "驳回";
            }
            return string.Format("{0}：{1} {2}此订单,操作：{3}，审批意见：{4}", DateTime.Now,
                OperatorProvider.Provider.GetCurrent().UserCode, "处理", tex, remak);
        }
    }
}
