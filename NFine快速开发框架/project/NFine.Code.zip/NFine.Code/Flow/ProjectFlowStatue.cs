﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NFine.Code.Flow
{
    public enum ProjectFlowStatue
    {
        /// <summary>
        /// 草稿
        /// </summary>
        [Description("草稿")] Draft = 0,
        /// <summary>
        /// 售前专员
        /// </summary>
        [Description("售前专员")] Sales = 1,
        /// <summary>
        ///带管理员分配
        /// </summary>
        [Description("管理员分配")] Distribution = 2,
        /// <summary>
        /// NPI专员审批
        /// </summary>
        [Description(" NPI专员审批")] NPIAudit = 3,
        /// <summary>
        /// NPI管理员审批
        /// </summary>
        [Description("NPI管理员审批")] NPIAdminAudit = 4,
        /// <summary>
        /// 发布
        /// </summary>
        [Description("发布")] Release = 5
    }
}
