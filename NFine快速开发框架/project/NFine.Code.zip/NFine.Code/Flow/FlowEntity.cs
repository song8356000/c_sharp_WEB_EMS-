﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NFine.Code.Flow
{
    /// <summary>
    /// 流程对象
    /// </summary>
    public class FlowEntity
    {
        /// <summary>
        /// 操作
        /// </summary>
        public int Action { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int Statue { get; set; }
        /// <summary>
        /// 审批意见
        /// </summary>
        public string Remark { get; set; }
        /// <summary>
        /// 流程单号
        /// </summary>
        public string FlowNo { get; set; }
        /// <summary>
        /// NPI员工
        /// </summary>
        public string NPIEmployee { get; set; }
    }
}
