﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NFine.Code.Flow
{
    public enum ActionType
    {
        /// <summary>
        /// 同意
        /// </summary>
        [Description("同意")] Consent = 1,
        /// <summary>
        /// 驳回
        /// </summary>
        [Description("驳回")] Reject
    }
}
