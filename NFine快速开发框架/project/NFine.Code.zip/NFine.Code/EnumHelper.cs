﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace NFine.Code
{
    public static class EnumHelper
    {

        /// <summary>
        /// 从枚举中获取Description
        /// 说明：
        /// 单元测试-->通过
        /// </summary>
        /// <param name="enumName">需要获取枚举描述的枚举</param>
        /// <returns>描述内容</returns>
        public static string GetDescription(this Enum enumName)
        {
            string _description = string.Empty;
            FieldInfo _fieldInfo = enumName.GetType().GetField(enumName.ToString());
            DescriptionAttribute[] _attributes = _fieldInfo.GetDescriptAttr();
            if (_attributes != null && _attributes.Length > 0)
                _description = _attributes[0].Description;
            else
                _description = enumName.ToString();
            return _description;
        }

        /// <summary>
        /// 获取字段Description
        /// </summary>
        /// <param name="fieldInfo">FieldInfo</param>
        /// <returns>DescriptionAttribute[] </returns>
        public static DescriptionAttribute[] GetDescriptAttr(this FieldInfo fieldInfo)
        {
            if (fieldInfo != null)
            {
                return (DescriptionAttribute[])fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), false);
            }
            return null;
        }
        /// <summary>
        /// 根据Description获取枚举
        /// 说明：
        /// 单元测试-->通过
        /// </summary>
        /// <typeparam name="T">枚举类型</typeparam>
        /// <param name="description">枚举描述</param>
        /// <returns>枚举</returns>
        public static T GetEnumName<T>(string description)
        {
            Type _type = typeof(T);
            foreach (FieldInfo field in _type.GetFields())
            {
                DescriptionAttribute[] _curDesc = field.GetDescriptAttr();
                if (_curDesc != null && _curDesc.Length > 0)
                {
                    if (_curDesc[0].Description == description)
                        return (T)field.GetValue(null);
                }
                else
                {
                    if (field.Name == description)
                        return (T)field.GetValue(null);
                }
            }
            throw new ArgumentException(string.Format("{0} 未能找到对应的枚举.", description), "Description");
        }
        /// <summary>
        /// 将枚举转换为ArrayList
        /// 说明：
        /// 若不是枚举类型，则返回NULL
        /// 单元测试-->通过
        /// </summary>
        /// <param name="type">枚举类型</param>
        /// <returns>ArrayList</returns>
        public static ArrayList ToArrayList(this Type type)
        {
            if (type.IsEnum)
            {
                ArrayList _array = new ArrayList();
                Array _enumValues = Enum.GetValues(type);
                foreach (Enum value in _enumValues)
                {
                    _array.Add(new KeyValuePair<Enum, string>(value, GetDescription(value)));
                }
                return _array;
            }
            return null;
        }

        /// <summary>
        /// 获取描述集合
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static List<string> GetDescriptList(this Type type)
        {
            if (type.IsEnum)
            {
                Array _enumValues = Enum.GetValues(type);
                return (from Enum value in _enumValues select GetDescription(value)).ToList();
            }
            return null;

        }

        /// <summary>
        /// 转换成字典
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static Dictionary<Enum, string> ToDictionary(this Type type)
        {
            if (type.IsEnum)
            {
                Array _enumValues = Enum.GetValues(type);
                return _enumValues.Cast<Enum>().ToDictionary(value => value, GetDescription);
            }
            return null;
        }


        /// <summary>
        /// 转换成字典
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static IEnumerable<Enum> ToList(this Type type)
        {
            if (type.IsEnum)
            {

                Array _enumValues = Enum.GetValues(type);

                return _enumValues.Cast<Enum>().ToList();
            }
            return null;
        }


        public static string GetDescription(Type type, int enumValue)
        {
            string _description = string.Empty;
            if (type.IsEnum)
            {
                Array _enumValues = Enum.GetValues(type);
                IEnumerable<Enum> enums = _enumValues.Cast<Enum>().ToList();
                foreach (var item in enums)
                {
                    if (Convert.ToInt32(item) == enumValue)
                    {
                        return GetDescription(item);
                    }
                }
            }
            return _description;
        }




        public static string EnumToJson(this Type type)
        {
            if (type.IsEnum)
            {
                Array _enumValues = Enum.GetValues(type);
                IEnumerable<Enum> enums = _enumValues.Cast<Enum>().ToList();
                var list = enums.Select(en => new
                {
                    value = Convert.ToInt32(en),
                    text = en.GetDescription()
                }).Cast<object>().ToList();
                return list.ToJson();
            }
            return string.Empty;
        }
    }
}
