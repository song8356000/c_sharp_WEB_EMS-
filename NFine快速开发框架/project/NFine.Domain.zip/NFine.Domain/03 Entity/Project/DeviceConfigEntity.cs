﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NFine.Domain.Entity.Project
{
    public class DeviceConfigEntity : IEntity<DeviceConfigEntity>, ICreationAudited, IModificationAudited
    {
        public string F_Id { get; set; }
        public string F_SN { get; set; }
        public string F_ProjectNo { get; set; }
        public DateTime? F_CreatorTime { get; set; }
        public string F_CreatorUserId { get; set; }
        public DateTime? F_LastModifyTime { get; set; }
        public string F_LastModifyUserId { get; set; }
        public string F_Remark { get; set; }
    }
}
