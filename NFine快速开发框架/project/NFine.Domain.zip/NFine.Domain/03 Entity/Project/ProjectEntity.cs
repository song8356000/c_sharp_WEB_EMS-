﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NFine.Domain.Entity.Project
{
    public class ProjectEntity : IEntity<ProjectEntity>, ICreationAudited, IModificationAudited
    {
        public string F_Id { get; set; }
        public string F_FlowNo { get; set; }
        public string F_SdpType { get; set; }
        public int F_Num { get; set; }
        /**供货日期*/
        public DateTime F_Deliverydate { get; set; }
        /**上线日期****/
        public DateTime F_Launchdate { get; set; }
        public string F_ProjectNo { get; set; }
        public string F_ConfigNo { get; set; }
        public string F_ProjectName { get; set; }
        public string F_ProductName { get; set; }
        public int F_Statue { get; set; }
        public DateTime ?F_CreatorTime { get; set; }
        public string F_CreatorUserId { get; set; }
        public DateTime ?F_LastModifyTime { get; set; }
        public string F_LastModifyUserId { get; set; }
        public string F_TemplateId { get; set; }
        /***审核人**/
        public string F_Auditor { get; set; }
        /// <summary>
        /// 上一个审批人
        /// </summary>
        public string F_OnAuditor { get; set; }
        public string F_Remark { get; set; }

    }
}
