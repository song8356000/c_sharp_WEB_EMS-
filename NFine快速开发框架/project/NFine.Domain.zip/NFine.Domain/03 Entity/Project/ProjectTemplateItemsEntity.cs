﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NFine.Domain.Entity.Project
{
    public class ProjectTemplateItemsEntity : IEntity<ProjectTemplateItemsEntity>
    {
        public string F_Id { get; set; }
        public string F_Name { get; set; }
        public string F_Specification { get; set; }
        public string F_Type { get; set; }
        public string F_AccessoryUrl { get; set; }
        public string F_TemplateId { get; set; }
        public string F_Code { get; set; }
        public string F_Remark { get; set; }
        public string F_ParentId { get; set; }
        public string F_ParentName { get; set; }
    }
}
