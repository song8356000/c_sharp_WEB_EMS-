﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NFine.Domain.Entity.Project
{
    public class DeviceConfigItemsEntity : IEntity<DeviceConfigItemsEntity>
    {
        public string F_Id { get; set; }
        public string F_Name { get; set; }
        public string F_Specification { get; set; }
        public string F_Type { get; set; }
        public string F_AccessoryUrl { get; set; }
        public string F_SN { get; set; }
        public string F_DeviceId { get; set; }
        public string F_Remark { get; set; }
    }
}
