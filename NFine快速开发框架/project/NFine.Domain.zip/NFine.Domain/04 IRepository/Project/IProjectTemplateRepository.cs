﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NFine.Data;
using NFine.Domain.Entity.Project;

namespace NFine.Domain.IRepository.Project
{
    public interface IProjectTemplateRepository : IRepositoryBase<ProjectTemplateEntity>
    {

    }
}
