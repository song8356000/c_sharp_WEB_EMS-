﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NFine.Data;
using NFine.Domain.Entity.Project;
using NFine.Domain.Entity.SystemSecurity;
using NFine.Domain.IRepository.Project;
using NFine.Domain.IRepository.SystemSecurity;

namespace NFine.Repository.Project
{
    public class DeviceConfigRepository : RepositoryBase<DeviceConfigEntity>,IDeviceConfigRepository
    {

    }
}
