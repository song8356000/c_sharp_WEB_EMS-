﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NFine.Application.Project;
using NFine.Code;
using NFine.Domain.Entity.Project;

namespace NFine.Web.Project
{
    public class ProjectItemsController :ControllerBase
    {
        //
        // GET: /ProjectItems/
        ProjectItemsApp app = new ProjectItemsApp();
        ProjectTemplateItemsApp  projectTemplateItemsApp=new ProjectTemplateItemsApp();  

        public ActionResult Index()
        {
            return View();
        }



        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetGridJson(string keyValue)
        {

            var data = app.GetList(keyValue);
            return Content(data.ToJson());
        }
        [HttpPost]
        [HandlerAjaxOnly]
        [ValidateAntiForgeryToken]
        public ActionResult SubmitForm(ProjectItemsEntity entity, string keyValue)
        {
            app.SubmitForm(entity, keyValue);
            return Success("操作成功。");
        }

        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteForm(string keyValue)
        {
            app.DeleteForm(keyValue);
            return Success("删除成功。");
        }


        [HttpPost]
        public ActionResult GetTemplateJson(string keyValue, string flowNo)
        {
            //1、默认从 Temp 数据里面 获取 ，如果有 
            var data = app.GetTemplateItems(keyValue,flowNo);
            if (data == null||data.Count==0) //从 data 如果为null 就从模板里面获取  在进行插入
            {
                var temps = projectTemplateItemsApp.GetList(keyValue); //从 模板里面取出 item数据信息
                //先清空垃圾数据
                app.DeleteTemp(flowNo);
                //插入 模板数据
                List<ProjectItemsEntity> projectItems=new List<ProjectItemsEntity>();
                foreach (var item in temps)
                {
                    ProjectItemsEntity entity = new ProjectItemsEntity();
                    entity.F_Name = item.F_Name;
                    entity.F_Specification = item.F_Specification;
                    entity.F_Type = item.F_Type;
                    entity.F_AccessoryUrl = item.F_AccessoryUrl;
                    entity.F_Code = item.F_Code;
                    entity.F_ProjectId = flowNo;
                    entity.F_TemplateId = keyValue;
                    entity.F_Remark = item.F_Remark;
                    entity.F_ParentId = item.F_ParentId;
                    entity.F_ParentName = item.F_ParentName;
                    app.SubmitForm(entity, "");
                    projectItems.Add(entity);
                }
                return Content(projectItems.ToJson());
            }
            return Content(data.ToJson());
        }



        [HttpPost]
        public ActionResult SaveData(ProjectItemsEntity entity)
        {

            app.Update(entity);

            return Success("保存成功");
        }

        /// <summary>
        /// 上传附件
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Uploda(ProjectItemsEntity entity)
        {

            var model = app.GetForm(entity.F_Id);
            model.F_AccessoryUrl = entity.F_AccessoryUrl;
            app.SubmitForm(model, entity.F_Id);
            return Success("保存成功");
        }

    }
}
