﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NFine.Application.Project;
using NFine.Code;
using NFine.Domain.Entity.Project;
namespace NFine.Web.Project
{
    public class DeviceConfigItemsController : ControllerBase
    {
        //
        // GET: /ProjectItems/
        DeviceConfigItemsApp app = new DeviceConfigItemsApp();
        public ActionResult Index()
        {
            return View();
        }



        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetGridJson(string keyValue)
        {
            var data = app.GetList(keyValue);
            return Content(data.ToJson());
        }
        [HttpPost]
        [HandlerAjaxOnly]
        [ValidateAntiForgeryToken]
        public ActionResult SubmitForm(DeviceConfigItemsEntity entity, string keyValue)
        {
            app.SubmitForm(entity, keyValue);
            return Success("操作成功。");
        }
        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteForm(string keyValue)
        {
            app.DeleteForm(keyValue);
            return Success("删除成功。");
        }

        [HttpPost]
        [HandlerAjaxOnly]
        public ActionResult SaveSn(string keyValue, string sn)
        {
            var entity = app.GetForm(keyValue);
            entity.F_Remark = GetRemark(sn, entity.F_SN, entity.F_Remark);
            entity.F_SN = sn;
            app.SubmitForm(entity, keyValue);
            return Success("保存成功。");
        }
        private string GetRemark(string sn, string oldSn, string remark)
        {

            string temp = "";
            if (string.IsNullOrEmpty(oldSn))
            {

                temp = string.Format("{0},{1}录入SN号:{2}", DateTime.Now,
                    OperatorProvider.Provider.GetCurrent().UserCode, sn);
            }
            else
            {
                temp = string.Format("{0},{1}修改SN号:{2}->{3}", DateTime.Now,
                    OperatorProvider.Provider.GetCurrent().UserCode, oldSn, sn);
            }
            if (!string.IsNullOrEmpty(remark))
            {
                temp = remark + "<br/>" + temp;
            }
            return temp;
        }
    }
}
