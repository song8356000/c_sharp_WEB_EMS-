﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NFine.Application.Project;
using NFine.Code;
using NFine.Domain.Entity.Project;

namespace NFine.Web.Project
{
    public class DeviceConfigController : ControllerBase
    {
        DeviceConfigApp app = new DeviceConfigApp();
        ProjectItemsApp projectItemsApp=new ProjectItemsApp();
        DeviceConfigItemsApp  deviceConfigItemsApp=new DeviceConfigItemsApp();
        ProjectApp projectApp=new ProjectApp();
        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetGridJson(Pagination pagination, string keyword)
        {
            var data = new
            {
                rows = app.GetList(pagination, keyword),
                total = pagination.total,
                page = pagination.page,
                records = pagination.records
            };
            return Content(data.ToJson());
        }
        [HttpPost]
        [HandlerAjaxOnly]
        [ValidateAntiForgeryToken]
        public ActionResult SubmitForm(DeviceConfigEntity entity, string keyValue)
        {
            app.SubmitForm(entity, keyValue);
            return Success("操作成功。");
        }
        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetFormJson(string keyValue)
        {
            var data = app.GetForm(keyValue);
            return Content(data.ToJson());
        }


        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteForm(string keyValue)
        {
            app.DeleteForm(keyValue);
            return Success("删除成功。");
        }

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetGridJson2()
        {
            var data = app.GetList();
            return Content(data.ToJson());
        }



        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetProjectItems(string projectNo, string deviceId)
        {
            var data = projectItemsApp.GetList(projectNo);
            var project = projectApp.GetFormByFlowNo(projectNo);
            //先清空 垃圾数据
            deviceConfigItemsApp.DeleteForm(deviceId);

            if (data != null && data.Count > 0)
            {
                foreach (var item in data)
                {
                    DeviceConfigItemsEntity deviceConfigItemsEntity = new DeviceConfigItemsEntity();
                    deviceConfigItemsEntity.F_AccessoryUrl = item.F_AccessoryUrl;
                    deviceConfigItemsEntity.F_DeviceId = deviceId;
                    deviceConfigItemsEntity.F_Id = Code.Common.GuId();
                    deviceConfigItemsEntity.F_Name = item.F_Name;
                    deviceConfigItemsEntity.F_Remark = item.F_Remark;
                    deviceConfigItemsEntity.F_Specification = item.F_Specification;
                    deviceConfigItemsEntity.F_Type = item.F_Type;
                    deviceConfigItemsApp.SubmitForm(deviceConfigItemsEntity, "");
                }
                //deviceConfigItemsApp.SubmitForm();
            }
            return Content(project.ToJson());
        }

    }
}
