﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NFine.Application.Project;
using NFine.Application.SystemManage;
using NFine.Code;
using NFine.Code.Flow;
using NFine.Domain.Entity.Project;
using NFine.Domain.Entity.SystemManage;

namespace NFine.Web.Project
{
    public class NewProjectController : ControllerBase
    {
        ProjectApp app=new ProjectApp();
        ProjectItemsApp projectItemsApp=new ProjectItemsApp();

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetGridJson(Pagination pagination, string keyword)
        {
            var data = new
            {
                rows = app.GetList(pagination, keyword),
                total = pagination.total,
                page = pagination.page,
                records = pagination.records
            };
        
            return Content(data.ToJson());
        }

        #region  审批数据
        /// <summary>
        /// 获取我申请的数据
        /// </summary>
        /// <param name="pagination"></param>
        /// <param name="keyword"></param>
        /// <returns></returns>
        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetMyApplyJson(Pagination pagination, string keyword)
        {
            var data = new
            {
                rows = app.GetMyApplyList(pagination, keyword),
                total = pagination.total,
                page = pagination.page,
                records = pagination.records
            };
            return Content(data.ToJson());
        }
        /// <summary>
        /// 获取带我审批的数据
        /// </summary>
        /// <param name="pagination"></param>
        /// <param name="keyword"></param>
        /// <returns></returns>

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetAuditorson(Pagination pagination, string keyword)
        {
            var data = new
            {
                rows = app.GetAuditorList(pagination, keyword),
                total = pagination.total,
                page = pagination.page,
                records = pagination.records
            };
            return Content(data.ToJson());
        }
        #endregion

        [HttpPost]
        [HandlerAjaxOnly]
        [ValidateAntiForgeryToken]
        public ActionResult SubmitForm(ProjectEntity entity, string keyValue, string ids)
        {
            if (string.IsNullOrEmpty(keyValue))
            {
                entity.F_Auditor = GetAudit(entity.F_Statue);
                entity.F_Statue = (int) ProjectFlowStatue.Distribution;
                entity.F_OnAuditor = Code.OperatorProvider.Provider.GetCurrent().UserCode;
                entity.F_Remark = string.Format("{0}：{1}创建订单，备注：{2}", DateTime.Now,
                    OperatorProvider.Provider.GetCurrent().UserCode, entity.F_Remark);
            }

            app.SubmitForm(entity, keyValue);
            projectItemsApp.UpdateIsShow(ids);
            //删除 多余项
            return Success("操作成功。");
        }

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetFormJson(string keyValue)
        {
            var data = app.GetForm(keyValue);
            return Content(data.ToJson());
        }


        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteForm(string keyValue)
        {
            app.DeleteForm(keyValue);
            return Success("删除成功。");
        }

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetGridJson2()
        {
            var data = app.GetList();
            return Content(data.ToJson());
        }

        [HttpPost]
        [HandlerAjaxOnly]
        public ActionResult Audit(FlowEntity flowEntity)
        {
            ProjectEntity projectEntity = app.GetFormByFlowNo(flowEntity.FlowNo);

            switch (flowEntity.Action)
            {
                case (int) ActionType.Consent: //同意
                    projectEntity.F_Statue = FlowHanle.GetNextStatue(projectEntity.F_Statue); //获取下一个状态
                    projectEntity.F_OnAuditor = projectEntity.F_Auditor; //上一个审批人
                    projectEntity.F_Auditor = projectEntity.F_Statue == (int) ProjectFlowStatue.NPIAudit
                        ? flowEntity.NPIEmployee
                        : GetAudit(projectEntity.F_Statue); //获取审批人
                 
                    break;
                case (int) ActionType.Reject: //驳回
                    projectEntity.F_Statue = FlowHanle.GetOnStatue(projectEntity.F_Statue); //获取下一个状态
                    projectEntity.F_Auditor = projectEntity.F_OnAuditor; //获取审批人
                    break;
            }
            projectEntity.F_Remark = projectEntity.F_Remark + "<br/>" +
                                     FlowHanle.GetRemarkTemplate(flowEntity.Action, flowEntity.Remark);
            app.Update(projectEntity);
            return Success("提交成功。");
        }

        UserApp userApp=new UserApp();
        [HttpPost]
        [HandlerAjaxOnly]
        public ActionResult GetNpiUser()
        {
            var data = userApp.GetUsers("NPI");
          
            return Content(data.ToJson());
        }
        [HttpGet]
        [HandlerAuthorize]
        public ActionResult MyAuditor()
        {
            return View();
        }
        [HttpGet]
        [HandlerAuthorize]
        public ActionResult MyApply()
        {
            return View();
        }

        /// <summary>
        /// 获取审批人
        /// </summary>
        /// <param name="currentStatue"></param>
        /// <returns></returns>
        public string GetAudit(int currentStatue)
        {
            string roleCode = FlowHanle.GetRole(currentStatue);
            List<UserEntity> users = userApp.GetUsers(roleCode); //获取 user信息
            if (users.Count > 0)
            {

                var firstOrDefault = users.FirstOrDefault();
                if (firstOrDefault != null)
                {
                    return firstOrDefault.F_Account;
                }
            }
            return string.Empty;
        }

    }
  
 
}
