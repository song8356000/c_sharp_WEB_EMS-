﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NFine.Web.Project
{
    public class UploadController : ControllerBase
    {
        //
        // GET: /Upload/

        public ActionResult Index()
        {
            return View();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Upload(HttpPostedFileBase fileData)
        {
            string saveName = string.Empty;
            try
            {
                string filePath = Server.MapPath("~/Uploads/");
                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }
                string fileName = Path.GetFileName(fileData.FileName); // 原始文件名称
                string fileExtension = Path.GetExtension(fileName); // 文件扩展名
                 saveName = Guid.NewGuid() + fileExtension; // 保存文件名称
                fileData.SaveAs(filePath + saveName);
            }
            catch (Exception exception)
            {
                FileLog.Error("上传文件异常:"+exception);
                return Error("上传失败。");
            }
            return Success("上传成功。", saveName);
        }


    }
}
