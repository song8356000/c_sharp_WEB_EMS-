﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NFine.Application.Project;
using NFine.Code;
using NFine.Domain.Entity.Project;

namespace NFine.Web.Project
{
    public class ProjectTemplateItemsController : ControllerBase
    {
        //
        // GET: /ProjectItems/
        private ProjectTemplateItemsApp app = new ProjectTemplateItemsApp();
        private ComponentApp componentApp = new ComponentApp();

        public ActionResult Index()
        {
            return View();
        }



        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetGridJson(string keyValue)
        {
            var data = app.GetList(keyValue);
            return Content(data.ToJson());
        }

        [HttpPost]
        [HandlerAjaxOnly]
        [ValidateAntiForgeryToken]
        public ActionResult SubmitForm(string tempId, string keyValue, string permissionIds)
        {
            string[] arrids = permissionIds.Split(new[] {","}, StringSplitOptions.RemoveEmptyEntries);
            foreach (var item in arrids)
            {
                ComponentEntity centity = componentApp.GetForm(item); //获取模块管理信息
                ProjectTemplateItemsEntity entity = new ProjectTemplateItemsEntity {F_ParentId = centity.F_ParentId};
                ComponentEntity parent = componentApp.GetForm(centity.F_ParentId); //获取父节点信息
                var list = componentApp.GetList(centity.F_Id); //获取子节点
                if (list == null || list.Count == 0) //当前不是父节点
                {
                    entity.F_ParentName = parent == null ? centity.Name : parent.Name;
                    entity.F_ParentId = parent == null ? centity.F_Id : parent.F_ParentId;
                    entity.F_Name = centity.Name;
                    entity.F_TemplateId = tempId;
                    app.SubmitForm(entity, keyValue);
                }
            }
            return Success("操作成功。");
        }
        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteForm(string keyValue)
        {
            app.DeleteForm(keyValue);
            return Success("删除成功。");
        }
    }
}
